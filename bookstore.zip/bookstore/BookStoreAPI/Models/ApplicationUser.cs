using Microsoft.AspNetCore.Identity;

namespace BookStoreAPI.Models
{
    public class ApplicationUser : IdentityUser
    {
        // extra profile fields can go here
    }
}
